/// <reference types="next" />
/// <reference types="next/image-types/global" />
import "./.next-dark-images-20261024/types/routes.d.ts";

// NOTE: This file should not be edited
// see https://nextjs.org/docs/app/api-reference/config/typescript for more information.
