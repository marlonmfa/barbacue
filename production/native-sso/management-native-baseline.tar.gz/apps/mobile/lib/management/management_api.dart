import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;

typedef Json = Map<String, dynamic>;

class ManagementException implements Exception {
  const ManagementException(this.message, {this.status = 0});
  final String message;
  final int status;
  @override
  String toString() => message;
}

class StaffSession {
  StaffSession(Json data)
    : name = data['name']?.toString() ?? 'Equipe',
      role = data['role']?.toString() ?? 'employee',
      mustChangePassword = data['mustChangePassword'] == true,
      permissions =
          (data['permissions'] as List? ??
                  defaultPermissions[data['role']] ??
                  [])
              .cast<String>();
  static const defaultPermissions = <String, List<String>>{
    'manager': [
      'dashboard',
      'orders',
      'ifood',
      'kitchen',
      'floor',
      'deliveries',
      'catalog',
      'offers',
      'tables',
      'customers',
      'settings',
      'service',
      'beta',
    ],
    'cashier': ['orders', 'ifood', 'tables'],
    'kitchen': ['kitchen'],
    'waiter': ['floor'],
    'driver': ['deliveries'],
  };
  final String name;
  final String role;
  final bool mustChangePassword;
  final List<String> permissions;
  bool can(String permission) =>
      role == 'admin' || permissions.contains(permission);
}

/// An isolated staff session. Credentials and cookies stay in memory and are
/// never shared with the customer apps, preferences, URLs or logs.
class ManagementApi {
  ManagementApi({http.Client? client, Uri? origin})
    : _client = client ?? http.Client(),
      origin =
          origin ??
          Uri.parse(
            const String.fromEnvironment(
              'MANAGEMENT_API_URL',
              defaultValue: 'https://barbacue.cog.ia.br',
            ),
          ) {
    if (this.origin.scheme != 'https' ||
        this.origin.host.isEmpty ||
        this.origin.userInfo.isNotEmpty ||
        this.origin.hasQuery ||
        this.origin.hasFragment ||
        (this.origin.path != '' && this.origin.path != '/')) {
      throw ArgumentError('A gestão exige uma origem HTTPS válida.');
    }
  }

  final http.Client _client;
  final Uri origin;
  String? _cookie;
  int _generation = 0;

  Future<dynamic> request(String method, String path, [Json? body]) async {
    if (!path.startsWith('/api/admin/') ||
        path.contains('..') ||
        path.contains('?')) {
      throw ArgumentError('Rota administrativa inválida.');
    }
    final generation = _generation;
    final request = http.Request(method, origin.resolve(path))
      ..followRedirects = false
      ..headers['Accept'] = 'application/json';
    if (_cookie != null) request.headers['Cookie'] = _cookie!;
    if (body != null) {
      request.headers['Content-Type'] = 'application/json';
      request.body = jsonEncode(body);
    }
    try {
      final response = await http.Response.fromStream(
        await _client.send(request),
      ).timeout(const Duration(seconds: 25));
      if (generation != _generation) {
        throw const ManagementException('A sessão foi encerrada.', status: 401);
      }
      if (method == 'GET' &&
          path == '/api/admin/auth' &&
          [404, 405].contains(response.statusCode)) {
        throw const ManagementException(
          'A gestão precisa de uma atualização no servidor. Peça ao administrador para publicar a API de sessão.',
          status: 405,
        );
      }
      // Reject redirects so the staff cookie never follows an external origin.
      if (response.statusCode >= 300 && response.statusCode < 400) {
        throw const ManagementException(
          'O servidor redirecionou a solicitação. Entre novamente.',
        );
      }
      final contentType = response.headers['content-type'] ?? '';
      if (!contentType.contains('application/json')) {
        throw const ManagementException(
          'O servidor não respondeu como esperado. Tente atualizar.',
        );
      }
      final dynamic data = jsonDecode(response.body);
      if (response.statusCode == 401) _cookie = null;
      if (response.statusCode < 200 || response.statusCode >= 300) {
        final message = data is Map ? (data['error'] ?? data['message']) : null;
        throw ManagementException(
          message is String && message != 'unauthorized'
              ? message
              : response.statusCode == 401
              ? 'Entre novamente para continuar.'
              : 'Não foi possível concluir. Atualize e tente novamente.',
          status: response.statusCode,
        );
      }
      final header = response.headers['set-cookie'];
      if (header != null) {
        final cookie = Cookie.fromSetCookieValue(header);
        if (cookie.name == 'barbacue_admin') {
          _cookie = cookie.maxAge == 0
              ? null
              : '${cookie.name}=${cookie.value}';
        }
      }
      return data;
    } on TimeoutException {
      throw ManagementException(
        method == 'GET'
            ? 'A conexão demorou. Tente atualizar.'
            : 'A confirmação demorou. Atualize antes de repetir a alteração.',
      );
    } on http.ClientException {
      throw const ManagementException(
        'Sem conexão. Verifique sua internet e tente atualizar.',
      );
    } on SocketException {
      throw const ManagementException(
        'Sem conexão. Verifique sua internet e tente atualizar.',
      );
    } on FormatException {
      throw const ManagementException(
        'Resposta inválida do servidor. Tente atualizar.',
      );
    }
  }

  Future<StaffSession> session() async => StaffSession(
    (await request('GET', '/api/admin/auth'))['session'] as Json,
  );

  Future<StaffSession> login(String username, String password) async {
    clear();
    try {
      await request('POST', '/api/admin/auth', {
        'username': username.trim(),
        'password': password,
      });
      return await session();
    } catch (_) {
      clear();
      rethrow;
    }
  }

  Future<void> logout() async {
    try {
      await request('DELETE', '/api/admin/auth');
    } finally {
      clear();
    }
  }

  void clear() {
    _generation++;
    _cookie = null;
  }

  void dispose() {
    clear();
    _client.close();
  }
}
