// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'product.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Product _$ProductFromJson(Map<String, dynamic> json) => Product(
  id: (json['id'] as num).toInt(),
  externalId: json['externalId'] as String?,
  categoryId: (json['categoryId'] as num).toInt(),
  name: json['name'] as String,
  description: json['description'] as String?,
  priceCents: (json['priceCents'] as num).toInt(),
  promoPriceCents: (json['promoPriceCents'] as num?)?.toInt(),
  promoStartsAt: json['promoStartsAt'] as String?,
  promoEndsAt: json['promoEndsAt'] as String?,
  imageUrl: json['imageUrl'] as String?,
  available: json['available'] as bool,
  sortOrder: (json['sortOrder'] as num).toInt(),
  ifoodUrl: json['ifoodUrl'] as String?,
);

Map<String, dynamic> _$ProductToJson(Product instance) => <String, dynamic>{
  'id': instance.id,
  'externalId': instance.externalId,
  'categoryId': instance.categoryId,
  'name': instance.name,
  'description': instance.description,
  'priceCents': instance.priceCents,
  'promoPriceCents': instance.promoPriceCents,
  'promoStartsAt': instance.promoStartsAt,
  'promoEndsAt': instance.promoEndsAt,
  'imageUrl': instance.imageUrl,
  'available': instance.available,
  'sortOrder': instance.sortOrder,
  'ifoodUrl': instance.ifoodUrl,
};

Category _$CategoryFromJson(Map<String, dynamic> json) => Category(
  id: (json['id'] as num).toInt(),
  name: json['name'] as String,
  slug: json['slug'] as String,
  sortOrder: (json['sortOrder'] as num).toInt(),
  products: (json['products'] as List<dynamic>)
      .map((e) => Product.fromJson(e as Map<String, dynamic>))
      .toList(),
);

Map<String, dynamic> _$CategoryToJson(Category instance) => <String, dynamic>{
  'id': instance.id,
  'name': instance.name,
  'slug': instance.slug,
  'sortOrder': instance.sortOrder,
  'products': instance.products,
};
