// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'order.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

OrderItem _$OrderItemFromJson(Map<String, dynamic> json) => OrderItem(
  productId: (json['productId'] as num).toInt(),
  name: json['name'] as String,
  priceCents: (json['priceCents'] as num).toInt(),
  qty: (json['qty'] as num).toInt(),
);

Map<String, dynamic> _$OrderItemToJson(OrderItem instance) => <String, dynamic>{
  'productId': instance.productId,
  'name': instance.name,
  'priceCents': instance.priceCents,
  'qty': instance.qty,
};

CreateOrderRequest _$CreateOrderRequestFromJson(Map<String, dynamic> json) =>
    CreateOrderRequest(
      customerName: json['customerName'] as String,
      customerPhone: json['customerPhone'] as String,
      deliveryAddress: json['deliveryAddress'] as String?,
      deliveryQuoteId: json['deliveryQuoteId'] as String?,
      brand: json['brand'] as String?,
      items: (json['items'] as List<dynamic>)
          .map((e) => OrderItem.fromJson(e as Map<String, dynamic>))
          .toList(),
      notes: json['notes'] as String?,
      couponCode: json['couponCode'] as String?,
      paymentMethod: json['paymentMethod'] as String? ?? 'pix',
      changeForCents: (json['changeForCents'] as num?)?.toInt(),
      channel: json['channel'] as String? ?? 'click',
      orderType: json['orderType'] as String? ?? 'delivery',
      tableToken: json['tableToken'] as String?,
    );

Map<String, dynamic> _$CreateOrderRequestToJson(CreateOrderRequest instance) =>
    <String, dynamic>{
      'customerName': instance.customerName,
      'customerPhone': instance.customerPhone,
      if (instance.deliveryAddress case final value?) 'deliveryAddress': value,
      if (instance.deliveryQuoteId case final value?) 'deliveryQuoteId': value,
      if (instance.brand case final value?) 'brand': value,
      'items': instance.items,
      if (instance.notes case final value?) 'notes': value,
      if (instance.couponCode case final value?) 'couponCode': value,
      'paymentMethod': instance.paymentMethod,
      if (instance.changeForCents case final value?) 'changeForCents': value,
      'channel': instance.channel,
      'orderType': instance.orderType,
      if (instance.tableToken case final value?) 'tableToken': value,
    };

PixInfo _$PixInfoFromJson(Map<String, dynamic> json) =>
    PixInfo(payload: json['payload'] as String);

Map<String, dynamic> _$PixInfoToJson(PixInfo instance) => <String, dynamic>{
  'payload': instance.payload,
};

OrderResponse _$OrderResponseFromJson(Map<String, dynamic> json) =>
    OrderResponse(
      orderId: json['orderId'] as String,
      paymentMethod: json['paymentMethod'] as String? ?? 'pix',
      orderType: json['orderType'] as String? ?? 'delivery',
      tableNumber: (json['tableNumber'] as num?)?.toInt(),
      totalCents: (json['totalCents'] as num?)?.toInt() ?? 0,
      deliveryFeeCents: (json['deliveryFeeCents'] as num?)?.toInt() ?? 0,
      deliveryDistanceMeters: (json['deliveryDistanceMeters'] as num?)?.toInt(),
      deliveryDurationSeconds: (json['deliveryDurationSeconds'] as num?)
          ?.toInt(),
      pix: json['pix'] == null
          ? null
          : PixInfo.fromJson(json['pix'] as Map<String, dynamic>),
    );
